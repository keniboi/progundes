//gameplay
wasd = move
graphics = 4k,hd 999999fps
jiggle physics = max 👀👀👀
ai = no (bad) ❌❌❌
game type = rpg i think
game = epic asf
visuals = godlike

//story
chapter = 42 type shiii 😈
boss = every 4 chapters 
type = harem (ouu shii 👀)
boss who = diablo harem monster 
adimral = johny sins 
second adimral = king nasir 
right hand = sweetie fox 🤤
left hand = gattouz0 
main character = randomly walked azaa 
super hero = Amraa 
super heros skill = infinity sperm 
weapon = 40inch dihh (omagaad)
reason to play = too much harem & epic asf 
map = ub city 2020 
last boss = zoloo
last boss skills = big black cock, huge sperm shot, fuck everything in his path summon 9999999999 harem 
quest = yes
how much quest = 10 in 1 chapter 
who give quest = zoozoo temka 
what is problem = uuganaa captured by zoloo and azaa to save him type shiiii 😭😭😭 
charecter design = full armor with big sword on some skyrim shii
zoloo design = huge dih n bulky asf naked 