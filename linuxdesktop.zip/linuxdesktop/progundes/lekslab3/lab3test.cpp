#include <stdio.h>
#include <stdlib.h>

int main(void)

{
int e,b,t,max;

    printf("Boldin bodson bodlogin too b=? ");

    scanf("%d",&b);

    t=b*2;

    printf ("\nTuyagyn bodson bodlin too t=%d",t);

    e=(b+t)/3;

    printf ("\nEnkhiin bodson bodlin too e=%d",e);

}
