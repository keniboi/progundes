#include <stdio.h>
#include <stdlib.h>

int main() {
    int k;
    printf("K tooniy utga oruulna uu: ");
    scanf("%d", &k);

    if (k >= 10 && k <= 20) {
        int aravt = k / 10;
        int negt = k % 10;
        int niilber = aravt + negt;
        printf("Niilber: %d\n", niilber);
    } 
    else 
    {
        int n = k;
        int negative = 0;
        if (n < 0) {
            negative = 1;
            n = -n;
        }

        int urvuu = 0;
        while (n != 0) {
            int digit = n % 10;
            urvuu = urvuu * 10 + digit;
            n /= 10;
        }

        if (negative) urvuu = -urvuu;

        printf("Urvuu utga: %d\n", urvuu);
    }

    printf("\n");
    system("pause");

    return 0;
}