#include <stdio.h>
#include <stdlib.h>

int main (void)
{

    int nas;

    printf("Tanii nas hed ve? ");
    scanf("%d",&nas);

    if (nas < 20)
    {
        printf("Ta usvur nastan baina.");
    }
    if (nas >= 20 && nas < 40)
    {
        printf("Ta zaluu nastan baina.");
    }
    if (nas >= 40)
    {
        printf("Ta ahimag nastan baina.");
    }

    printf("\n");
    system("pause");
    return 0;

}