#include <stdio.h>
#include <stdlib.h>

int main(void)

{
    int too1, too2, too3;

    printf ("Too1 oruulna uu: ");
    scanf("%d",&too1);
    printf ("Too2 oruulna uu: ");
    scanf("%d",&too2);
    printf ("Too3 oruulna uu: ");
    scanf("%d",&too3);

    if (too1>too2 && too1>too3)
    {
        printf("Ih too: %d",too1);
    }
    else if (too2>too1 && too2>too3)
    {
        printf("Ih too: %d",too2);
    }
    else
    {
        printf("Ih too: %d",too3);
    }
    printf("\n");
    system("pause");
    return 0;
}