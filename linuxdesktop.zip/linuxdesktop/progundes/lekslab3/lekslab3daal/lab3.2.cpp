#include <stdio.h>
#include <stdlib.h>

int main(void)

{
    int onoo;

    printf("Uriin onoo oruulna uu: ");
    scanf("%d",&onoo); 

    if (onoo == 100)
    {
        printf("Tanii unelgee A+");
    }

    else if (onoo >= 93)
    {
        printf("Tanii unelgee A");
    }

    else if (onoo >= 90)
    {
        printf("Tanii unelgee A-");
    }
    else if(onoo >= 87)
    {
        printf("Tanii unelgee B+");
    }
    else if(onoo >= 83)
    {
        printf("Tanii unelgee B");
    }
    else if(onoo >= 80)
    {
        printf("Tanii unelgee B-");
    }
    else if(onoo >= 77)
    {
        printf("Tanii unelgee C+");
    }
    else if(onoo >= 73)
    {
        printf("Tanii unelgee C");
    }
    else if(onoo >= 70)
    {
        printf("Tanii unelgee C-");
    }
    else if(onoo >= 67)
    {
        printf("Tanii unelgee D+");
    }
    else if(onoo >= 63)
    {
        printf("Tanii unelgee D");
    }
    else if(onoo >= 60)
    {
        printf("Tanii unelgee D-");
    }
    else
    {
        printf("Tanii unelgee F");
    }
    printf("\n");
    system("pause");

    return 0;
}