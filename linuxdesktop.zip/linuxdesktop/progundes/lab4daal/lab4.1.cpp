#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main ()
{
    int n, t, d=0;
    printf("N toonii utga oruulna uu: ");
    scanf("%d", &n);
    t=n;
    while (t>0)
    {
        d++;
        t=t/10;
    }
    int p = (int)pow(10, d-1);
    printf("Ehnii too: %d\n", n/p);
    printf("Suuldiin too: %d\n", n%10);

    if(d%2==1)
    {
        printf("Golyn too: %d\n", (n / (int)pow(10, d / 2)) % 10);
    }
    else
    {
        printf("Golyn toonuud: %d\n", (n / (int)pow(10, d / 2 - 1)) % 100);
    }
    return 0;
}