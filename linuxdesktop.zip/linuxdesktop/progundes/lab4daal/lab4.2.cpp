#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main() {
    int x, sum = 0;
    printf("Too oruulna uu (0 bol duusna): ");
    scanf("%d", &x);

    while (x != 0) 
    {
        if (x > 0) 
        {
            sum += x;
        }
        scanf("%d", &x);
    }

    printf("Eyreg toonuudin niilber: %d\n", sum);
    return 0;
}