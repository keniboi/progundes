#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main ()
{
    int n, i=1, tegshniil = 0, sondgoiniil = 0;
    printf("N toonii utga oruulna uu: ");
    scanf("%d", &n);

    do 
    {
        if (i%2==0)
        {
            tegshniil += i;
        }
        else
        {
            sondgoiniil += i;
        }
        i++;
    }
    while (i<=n);

    printf("Tegsh toonuudin niilber: %d\n", tegshniil);
    printf("Sondgoi toonuudin niilber: %d\n", sondgoiniil);
    system("pause");
    return 0;
}