#include <stdio.h>

int main() {
    int n, i;
    int namhan = 0, dund = 0, undur = 0;
    double h;

    printf("Suralstsagchdyn too: ");
    scanf("%d", &n);

    for (i = 1; i <= n; i++) {
        printf("%d-r suralstsagchiin undur (cm): ", i);
        scanf("%lf", &h);

        if (h < 160) {
            namhan++;
        } else if (h <= 175) {
            dund++;
        } else {
            undur++;
        }
    }

    printf("Namhan: %d\n", namhan);
    printf("Dund zereg: %d\n", dund);
    printf("Undur: %d\n", undur);
    return 0;
}