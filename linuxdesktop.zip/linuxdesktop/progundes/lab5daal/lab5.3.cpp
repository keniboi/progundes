#include <stdio.h>

int main() {
    int day;
    printf("Garagiin dugaar (1-7): ");
    scanf("%d", &day);

    switch (day) {
        case 1: printf("Davaa\n");    break;
        case 2: printf("Myagmar\n");  break;
        case 3: printf("Lkhagva\n");  break;
        case 4: printf("Purev\n");    break;
        case 5: printf("Baasan\n");   break;
        case 6: printf("Byamba\n");   break;
        case 7: printf("Nyam\n");     break;
        default: printf("1-7 hoorond too oruulna uu.\n");
    }
    return 0;
}