#include <stdio.h>
#include <stdlib.h>

int main() {
    int n, a, i;
    int niilber = 0, sondtoo = 0;

    printf("n: ");
    scanf("%d", &n);

    for (i = 1; i <= n; i++) 
    {
        printf("a%d: ", i);
        scanf("%d", &a);

        if (a%2==0) 
        {
            niilber += a;
        } 
        else if (a%2!=0) 
        {
            sondtoo++;
        }
    }

    printf("Eyreg gishuudiin niilber: %d\n", niilber);
    printf("Surgu gishuudiin too: %d\n", sondtoo);
    return 0;
}