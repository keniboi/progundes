#include <iostream>

int nemelt(int x, int y) 
{
    return x + y;
}

int urjver(int x, int y) 
{
    return x * y;
}

int nemegduulel (int x)
{
    x=x+10;
    std::cout << "function dotor: x = " << x << std::endl;
    return x;
}

int square (int x)
{
    x = x * x;
    return x;
}

int cube (int x)
{
    x = x * x * x;
    return x;
}

double average(double a, double b, double c)
{
    return (a + b + c) / 3.0;
}

using namespace std;

int main (void)
{
    int songolt;
    do {
        std::cout << "1. Bodoh\n0. Garah\nSongoltoo oruulna uu: ";
        std::cin >> songolt;

        if (songolt == 1) {
            int a, b, c;
            std::cout << "3 toog oruulna uu: ";
            std::cin >> a >> b >> c;
            int s = nemelt(a, b);
            double avg = average(a, b, c);
            int p = urjver(a, b);
            int f = nemegduulel(a);
            int q = square(b);
            int l = cube(c);
            std::cout << "Niilber: " << s << std::endl;
            std::cout << "Urjver: " << p << std::endl;
            std::cout << "b^2: " << q << std::endl;
            std::cout << "c^3: " << l << std::endl;
            std::cout << "Dundaj: " << avg << std::endl;
        } else if (songolt != 0) {
            std::cout << "Buruu songolt. Dahin oroldono uu.\n";
        }
    } while (songolt != 0);
    return 0;
}