#include <stdio.h>
#include <stdlib.h>

int main(void)

{
    int grade;

    printf("Onoogoo oruulna uu: ");
    scanf("%d",&grade);

    if (grade >= 60)
    {
        printf("Passed\n");
    }
    else
    {
        printf("Failed\n");
        printf("Dahin suraltsah heregte bolloo!");
    }
    printf("\n");
    system("pause");

    return 0;
}