#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(void)
{
    float x,y,n;

    printf("******Do While********\n");

    printf("n: ");
    scanf("%f",&n);
    x=1;
    do 
    {
        (y=(3.2+sqrt(float(x+1)))/5*n);
        printf("\n x=%f",x);
        printf(" ;     y=%f",y);
        x=x+0.5;
    } while (x <= n);
    printf("\n");

    system("pause");
    return 0;
}