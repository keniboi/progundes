#include <stdio.h>
#include <stdlib.h>

int main() 
{
    float a,b,c;
    printf("3 toonii utga oruulna uu: ");
    scanf("%f %f %f", &a, &b, &c);
    if (a>b && a>c)
    {
        printf("Tom utga: %.2f\n", a);
    }
    else if (b>a && b>c)
    {
        printf("Tom utga: %.2f\n", b);
    }
    else
    {
        printf("Tom utga: %.2f\n", c);
    }
    printf("\n");
    system("pause");
    return 0;
}