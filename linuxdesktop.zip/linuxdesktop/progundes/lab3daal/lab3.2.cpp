#include <stdio.h>
#include <stdlib.h>

int main(void)

{
    int too;

    printf ("Too oruulna uu: ");
    scanf("%d",&too);

    if (too%2==0)
    {
        printf("Too tegsh baina.");
    }
    else
    {
        printf("Too sondgoi baina.");
    }
    printf("\n");
    system("pause");
    return 0;
}