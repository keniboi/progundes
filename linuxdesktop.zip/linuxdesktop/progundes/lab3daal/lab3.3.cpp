#include <stdio.h>
#include <stdlib.h>

int main () 
{
    int x, bonus;
    printf("Tanii hudaldaanii une oruulna uu: ");
    scanf ("%d", &x);
    if (x<=100)
    {
        bonus = 5;
    }
    else if (x>100 && x<1000)
    {
        bonus = x*.2;
    }
    else if (x>=1000)
    {
        bonus = x*.1;
    }
    
    if (x%2 == 0)
    {
        bonus += 1;
    }
    else if (x%10==5)
    {
        bonus += 2;
    }
    printf("Uramshuullin onoo: %d\n", bonus);
    printf("Tanii hudaldaanii une: %d\n", x+bonus);
    system("pause");
    return 0;
}