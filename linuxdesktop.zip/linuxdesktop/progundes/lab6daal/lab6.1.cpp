#include <stdio.h>
#include <stdlib.h>

// p(y) = a6*y^6 + a5*y^5 + ... + a0
double p(const double a[], double y) {
    double result = 0;
    for (int i = 6; i >= 0; i--)
        result = result * y + a[i];
    return result;
}

// p(x+1) - p(x)
double difference(const double a[], double x) {
    return p(a, x + 1) - p(a, x);
}

bool isEven(long long n) {
    return n % 2 == 0;
}

unsigned long long factorial(int n) {
    unsigned long long f = 1;
    for (int i = 2; i <= n; i++)
        f *= i;
    return f;
}

//N hurtelh toonii sondgoi, tegsh factorial
void factorialSums(int N, unsigned long long &evenSum, unsigned long long &oddSum) {
    evenSum = 0;
    oddSum = 0;
    for (int i = 1; i <= N; i++) {
        if (isEven(i))
            evenSum += factorial(i);
        else
            oddSum += factorial(i);
    }
}

void daal1()
{
    double a[7];
    printf("1). a0..a6 gsn toonuud oruulna uu:\n");
    for (int i = 0; i <= 6; i++) {
        printf("a%d = ", i);
        scanf("%lf", &a[i]);
    }
    int xs[3] = {1, 3, 4};
    for (int k = 0; k < 3; k++)
        printf("x = %d:  p(x+1) - p(x) = %.4f\n", xs[k], difference(a, xs[k]));
}

void daal2()
{
    long long num;
    printf("\n2). Too oruulna uu: ");
    scanf("%lld", &num);
    if (isEven(num))
        printf("%lld tegsh too\n", num);
    else
        printf("%lld sondgoi too\n", num);
}

void daal3()
{
    int N;
    printf("\n3). N oruulna uu (1..20): ");
    scanf("%d", &N);
    if (N < 1 || N > 20) {
        printf("N too 1-20 hoorond baih ystoi.\n");
        return;
    }
    unsigned long long evenSum, oddSum;
    factorialSums(N, evenSum, oddSum);
    printf("Sondgoi toonuudin factorial niilber %d = %llu\n", N, evenSum);
    printf("Tegsh toonuudin factorial niilber %d = %llu\n", N, oddSum);
}

int main() 
{
    int choice;
    do 
    {
        printf("1 - Task 1 (p(x+1) - p(x))\n");
        printf("2 - Task 2 (even / odd)\n");
        printf("3 - Task 3 (sum of factorials)\n");
        printf("0 - Exit\n");
        printf("Choose: ");
        scanf("%d", &choice);
        
        switch (choice) 
        {
            case 1:
                daal1();
                break;
            case 2:
                daal2();
                break;
            case 3:
                daal3();
                break;
            case 0:
                printf("Exiting...\n");
                break;
            default:
                printf("Tym songolt bhgu, dhiad oruulna uu\n");
        }
    }
    while (choice != 0);
    return 0;
}