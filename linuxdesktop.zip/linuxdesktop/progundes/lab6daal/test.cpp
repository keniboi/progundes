#include <stdio.h>

int maximum(int a, int b, int c)
{
    int max;
    if (a >= b && a >= c) 
    {
        max = a;
    } 
    else if (b >= a && b >= c) 
    {
        max = b;
    } 
    else 
    {
        max = c;
    }
    return max;
}

int main()
{
    int a, b, c;
    printf("3 toonii utga oruulna uu: ");
    scanf("%d %d %d", &a, &b, &c);
    printf("%d", maximum(a, b, c));
    return 0;
}