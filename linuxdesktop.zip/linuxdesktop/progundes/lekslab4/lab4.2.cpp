#include <stdio.h>
#include <stdlib.h>

int main()
{
    int M, I, J;
    float x, Z;
    double P;

    printf("x=");
    scanf("%f", &x);
    printf("M (sondgoi, suulin oron)=");
    scanf("%d", &M);

    Z = 1;
    for (I = 3; I <= M; I += 2)
    {
        P = 1;
        for (J = 1; J <= I; J++)
        {
            P = P * J;
        }
        Z = Z + (I * x) / P;
    }
    printf("\nZ= %f\n", Z);

    system("pause");
    return 0;
}