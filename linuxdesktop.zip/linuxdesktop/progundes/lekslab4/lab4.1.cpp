#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, i, j;
    long long p, facto;

    printf("n=");
    scanf("%d", &n);

    facto = 0;
    for (i = 1; i <= n; i += 2)
    {
        p = 1;
        for (j = 1; j <= i; j++)
        {
            p = p * j;
        }
        facto = facto + p;
    }
    printf("\nSondgoi toonuudin factorial niilberuud= %d = %lld\n", n, facto);

    system("pause");
    return 0;
}