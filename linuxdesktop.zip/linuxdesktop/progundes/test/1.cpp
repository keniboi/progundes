#include <stdio.h>

int main(void) {
    int counter = 1;

    while (counter <= 9) {
        printf("%d\n", counter);
        counter++;
    }
    getchar();
    
    return 0;
}