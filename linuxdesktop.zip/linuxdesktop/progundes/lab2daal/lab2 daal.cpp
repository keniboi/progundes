#include <iostream>
#include <cmath>
#include <string>
using namespace std;

void task1() {
    double x, M;
    printf("x-iin utgiig oruulna uu: ");
    cin >> x;
    M = x / 100;
    printf("M = %f\n", M);
}

void task2() {
    string ovog, ner, mergejil;
    printf("Ovgoo oruulna uu: ");
    cin >> ovog;
    printf("Nereee oruulna uu: ");
    cin >> ner;
    printf("Suraltsaj bui mergejlee oruulna uu: ");
    cin.ignore();
    getline(cin, mergejil);

    printf("Sain baina uu, %s ovogtoi %s! Ta \"%s\" mergejleer suraltsaj baina uu?\n", ovog.c_str(), ner.c_str(), mergejil.c_str());
}

void task3() {
    double a, b, c;
    printf("Gurvaljny 3 taliig oruulna uu (a b c): "); 
    cin >> a >> b >> c;

    if (a + b > c && a + c > b && b + c > a) {
        double p = (a + b + c) / 2.0;
        double S = sqrt(p * (p - a) * (p - b) * (p - c));
        printf("Gurvaljny talbai S = %f\n", S);
    }
    else {
        printf("Iim taluudtai gurvaljin baihgui!\n");
    }
}

void task4() {
    double a, b, c;
    printf("Koefficientuudiig oruulna uu (a b c): ");
    cin >> a >> b >> c;

    if (a == 0) {
        if (b == 0) {
            if (c == 0) printf("x ni duriin too baij bolno.\n");
            else printf("Shiid baihgui.\n");
        }
        else {
            printf("x = %f\n", -c / b);
        }
        return;
    }

    double D = b * b - 4 * a * c;
    if (D > 0) {
        double x1 = (-b + sqrt(D)) / (2 * a);
        double x2 = (-b - sqrt(D)) / (2 * a);
        printf("x1 = %f, x2 = %f\n", x1, x2);
    }
    else if (D == 0) {
        double x = -b / (2 * a);
        printf("x = %f (davhar yazguur)\n", x);
    }
    else {
        printf("Bodit yazguurgui (D < 0).\n");
    }
}

void task5() {
    long long m, n;
    printf("m, n natural toonuudiig oruulna uu: ");
    cin >> m >> n;

    long long result = 1;
    for (long long i = 0; i < n; i++) {
        result *= m;
    }
    printf("%lld^%lld = %lld\n", m, n, result);
}

void task6() {
    int M;
    int i;
    int c;

    printf("Natural too M-iig oruulna uu: ");
    scanf("%d", &M);
    for (i = 1; i <= M; i++) {
        c = i * M;
        printf("%dx%d = %d\n", i, M, c);
    }
}

void task7() {
    int N;
    int i;
    printf("N toog oruulna uu: ");
    cin >> N;

    long long sum = 1;
    for (i = 1; i <= N; i++) {
        if (i % 2 != 0) sum *= i;
    }
    printf("1-ees %d hurtelkh sondgoi toonuudyn urjver = %lld\n", N, sum);
}

void task8() {
    int ehlel;
    ehlel = 3;

    int a = ehlel;
    for (int i = 0; i < 15; i++) {
        printf("(%d,%d) ", a, a + 2);
        a += 2;
    }
    printf("\n");
}

void task9() {
    double a, b;
    printf("2 katetiig oruulna uu (a b): ");
    cin >> a >> b;

    double c = sqrt(a * a + b * b);
    printf("Gipotenuz c = %f\n", c);
}

int main() {
    int choice;
    printf("===== Daalgavruud =====\n");
    printf("1. x -> M = x/100\n");
    printf("2. Ovog, ner, mergejil asuukh\n");
    printf("3. Gurvaljny talbai\n");
    printf("4. Kvadrat tegshitgel\n");
    printf("5. m zereg n\n");
    printf("6. M toony khurdiig\n");
    printf("7. 1..N dekh sondgoi toonuudyn niilber\n");
    printf("8. Yalgavar 2 baikh 15 khos\n");
    printf("9. Tegsh untsugt gurvaljny gipotenuz\n");
    printf("Daalgavryn dugaaraa songono uu (1-9): ");
    cin >> choice;

    switch (choice) {
    case 1: task1(); break;
    case 2: task2(); break;
    case 3: task3(); break;
    case 4: task4(); break;
    case 5: task5(); break;
    case 6: task6(); break;
    case 7: task7(); break;
    case 8: task8(); break;
    case 9: task9(); break;
    default: cout << "Buruu songolt!" << endl;
    }
    system("pause");
    return 0;
}